#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, pathlib, sys
try:
    from jsonschema import Draft202012Validator
except Exception as e:
    raise SystemExit(f"jsonschema required: {e}")

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p): return json.loads(p.read_text(encoding='utf-8'))
def require(cond,msg):
    if not cond: raise AssertionError(msg)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--return-dir',required=True); ap.add_argument('--source-root'); a=ap.parse_args(); r=pathlib.Path(a.return_dir).resolve()
    # SHA256SUMS covers everything except itself.
    lines=(r/'SHA256SUMS').read_text().splitlines(); seen=set()
    for line in lines:
        h,rel=line.split('  ',1); p=r/rel; require(p.is_file(),f'missing {rel}'); require(sha(p)==h,f'hash mismatch {rel}'); seen.add(rel)
    files={p.relative_to(r).as_posix() for p in r.rglob('*') if p.is_file() and p.name!='SHA256SUMS'}
    require(seen==files,f'SHA256SUMS set mismatch missing={sorted(files-seen)} extra={sorted(seen-files)}')
    b=load(r/'binding.fixture.json')
    binding_keys=set('contract schema_version status product_slug source_product source_instance_id tenant_id integration_instance_id enabled qualification network_profile origin alternative_same_host_port ui_origin resolved_address_allowlist base_path tls auth endpoints limits action_plane deployment_role evidence'.split())
    require(set(b)==binding_keys,'binding top-level fields not exact'); require(b['status']=='RETURNED_UNQUALIFIED' and b['qualification']=='IMPLEMENTED_UNQUALIFIED' and b['enabled'] is False,'binding qualification/enabled truth')
    require(b['base_path']=='/api/integrations/dashboard/v1' and b['source_product']=='WAF' and b['auth']['profile']=='opaque_bearer','binding identity/contract')
    require(set(b['auth']['scopes'])==set(['dashboard:read:health','dashboard:read:capabilities','dashboard:read:assets','dashboard:read:detections','dashboard:read:policies','dashboard:read:health-observations']),'scope set mismatch')
    resources=b['endpoints']['resources']; require(len(resources)==6,'resource count'); enabled=[x for x in resources if x['enabled']]; require({x['capability'] for x in enabled}=={'LIST_ASSETS','LIST_DETECTIONS','OBSERVE_POLICY','HEALTH'},'enabled capability set')
    require(all(x['sync_modes']==[] for x in resources if not x['enabled']),'disabled route sync modes')
    identity=load(r/'identity-inputs.json')
    if a.source_root:
        source=pathlib.Path(a.source_root).resolve()
        for entry in identity['files']:
            path=source/entry['path']; require(path.is_file(),f"identity source missing {entry['path']}")
            require(sha(path)==entry['sha256'],f"identity source hash mismatch {entry['path']}")
    m=load(r/'adapter-manifest.fixture.json'); require(set(m)==set('adapter_id product_type vendor protocol_version identity_sha256 capabilities capability_generation qualification_status qualification_evidence_sha256'.split()),'manifest nine fields')
    require(m['identity_sha256']==sha(r/'identity-inputs.json'),'identity hash mismatch'); require(m['qualification_status']=='UNQUALIFIED' and m['qualification_evidence_sha256'] is None,'manifest qualification truth')
    bun=load(r/'fixture-bundle.json'); require(set(bun)=={'manifest','product','responses','requests','negative_pages'},'bundle five fields'); require(bun['manifest']==m,'embedded manifest mismatch'); require(set(bun['product'])=={'tenant_id','product_id','product_type','enabled','secret_ref'},'product five fields')
    pagev=Draft202012Validator(load(r/'schemas/page.schema.json')); ctlv=Draft202012Validator(load(r/'schemas/control.schema.json'))
    positive=0
    for route,bodies in bun['responses'].items():
        for body in bodies:
            errs=list((ctlv if route.endswith('/health') or route.endswith('/capabilities') else pagev).iter_errors(body))
            require(not errs,f'schema errors {route}: {[e.message for e in errs[:3]]}')
            positive += 1
    for n in bun['negative_pages']:
        require(list(pagev.iter_errors(n['page'])),f"negative page unexpectedly valid: {n.get('route_name')}")
    # Ensure all request cursors follow exact preceding response cursor chain for each lane.
    positions={}
    for req in bun['requests']:
        route={'ASSET':'assets','DETECTION':'detections','POLICY':'policies','HEALTH':'health-observations'}[req['resource_kind']]
        path='/api/integrations/dashboard/v1/'+route; i=positions.get(path,0); require(i<len(bun['responses'][path]),f'no response body for request {path} #{i}')
        if i==0: require(req['cursor'] is None,f'first cursor not null {path}')
        else: require(req['cursor']==bun['responses'][path][i-1]['next_cursor'],f'cursor chain mismatch {path} #{i}')
        positions[path]=i+1
    require(all(positions.get(k,0)==len(v) for k,v in bun['responses'].items() if not k.endswith('/health') and not k.endswith('/capabilities')),'unused resource responses')
    request_fields={'tenant_id','product_id','capability','resource_kind','cursor','page_size'}
    allowed_errors={'ProductConnectorError','ProductConnectorConflictError','ProductConnectorCursorError'}
    neg=load(r/'negative-cases.json'); require(len(neg)==13 and all(set(x)=={'case_id','stage','input_fixture','request','expected_error','reason'} for x in neg),'negative catalog shape')
    expected_negative_ids={'N-01','N-02','N-03','N-04','N-05','N-06','N-07','N-08','N-09','N-10','N-11','N-13','N-15'}
    require({x['case_id'] for x in neg}==expected_negative_ids,'negative catalog case set')
    expected_stages={
      'N-01':'decode','N-02':'decoder','N-03':'decoder','N-04':'decoder','N-05':'page_validate',
      'N-06':'decoder','N-07':'decoder','N-08':'decoder','N-09':'page_validate','N-10':'page_validate',
      'N-11':'sync','N-13':'sync','N-15':'sync',
    }
    null_request_cases={'N-01','N-03','N-04'}
    schema_decoder_cases={'N-02','N-06','N-07','N-08'}
    for x in neg:
        fixture_path=r/x['input_fixture']; require(fixture_path.is_file(),f"negative fixture missing {x['input_fixture']}")
        require(x['expected_error'] in allowed_errors,f"Dashboard error class not executable: {x['case_id']}")
        require(x['stage']==expected_stages[x['case_id']],f"negative stage mismatch: {x['case_id']}")
        if x['case_id'] in null_request_cases:
            require(x['request'] is None,f"request must be null at decoder stage: {x['case_id']}")
        else:
            require(isinstance(x['request'],dict) and set(x['request'])==request_fields,f"six-field request missing: {x['case_id']}")
        fixture=load(fixture_path)
        if x['stage']=='decoder':
            require(isinstance(fixture,dict) and 'steps' not in fixture,f"decoder case must reference one page: {x['case_id']}")
            schema_errors=list(pagev.iter_errors(fixture))
            if x['case_id'] in schema_decoder_cases:
                require(schema_errors,f"schema decoder fixture unexpectedly valid: {x['case_id']}")
            else:
                require(not schema_errors,f"binding decoder case failed JSON schema first: {x['case_id']}")
        if x['stage']=='page_validate':
            require(isinstance(fixture,dict) and 'steps' not in fixture,f"page_validate case must reference one page: {x['case_id']}")
            require(not list(pagev.iter_errors(fixture)),f"page_validate fixture failed decoder first: {x['case_id']}")
        if x['stage']=='sync':
            require(isinstance(fixture,dict) and set(fixture)=={'steps'},f"sync case must use exact sequence fixture: {x['case_id']}")
            steps=fixture['steps']; require(isinstance(steps,list) and len(steps)>=2,f"sync sequence needs prelude and failure steps: {x['case_id']}")
            pages=[]
            for i,step_data in enumerate(steps):
                require(isinstance(step_data,dict) and set(step_data)=={'fixture','request'},f"sequence step shape: {x['case_id']} step {i+1}")
                rel=step_data['fixture']; require(isinstance(rel,str) and rel and not pathlib.PurePosixPath(rel).is_absolute() and '..' not in pathlib.PurePosixPath(rel).parts,f"unsafe sequence fixture: {x['case_id']} step {i+1}")
                page_path=r/rel; require(page_path.is_file(),f"sequence page missing: {x['case_id']} step {i+1}")
                request=step_data['request']; require(isinstance(request,dict) and set(request)==request_fields,f"sequence request shape: {x['case_id']} step {i+1}")
                page=load(page_path); require(isinstance(page,dict) and 'steps' not in page,f"sequence step must reference a page: {x['case_id']} step {i+1}")
                require(not list(pagev.iter_errors(page)),f"sync sequence page fails decoder before sync: {x['case_id']} step {i+1}")
                pages.append(page)
                if i==0: require(request['cursor'] is None,f"sequence first cursor must be null: {x['case_id']}")
                else: require(request['cursor']==pages[i-1]['next_cursor'],f"sequence cursor mismatch: {x['case_id']} step {i+1}")
            require(steps[-1]['request']==x['request'],f"catalog request must equal failing sequence request: {x['case_id']}")
            require(steps[-1]['fixture'].startswith('fixtures/negative/'),f"final failure page must be negative fixture: {x['case_id']}")
    positive_cases=load(r/'positive-sequence-cases.json')
    require(isinstance(positive_cases,list) and len(positive_cases)==1,'positive sequence catalog shape')
    positive_case=positive_cases[0]
    require(set(positive_case)=={'case_id','stage','input_fixture','expected_current_revision','expected_history_contains_revision','reason'},'positive sequence case fields')
    require(positive_case['case_id']=='P-01-OLD-REVISION-HISTORY' and positive_case['stage']=='sync','old revision positive case identity')
    positive_sequence=load(r/positive_case['input_fixture'])
    require(set(positive_sequence)=={'steps'} and len(positive_sequence['steps'])==2,'old revision positive sequence shape')
    positive_pages=[]
    for i,step_data in enumerate(positive_sequence['steps']):
        require(set(step_data)=={'fixture','request'} and set(step_data['request'])==request_fields,f'old revision step shape {i+1}')
        require(step_data['fixture'].startswith('fixtures/positive/'),f'old revision step must reference positive fixture {i+1}')
        page=load(r/step_data['fixture']); require(not list(pagev.iter_errors(page)),f'old revision step decoder failure {i+1}'); positive_pages.append(page)
        if i==0: require(step_data['request']['cursor'] is None,'old revision first cursor')
        else: require(step_data['request']['cursor']==positive_pages[i-1]['next_cursor'],'old revision cursor chain')
    first_revision=positive_pages[0]['records'][0]['revision']; older_revision=positive_pages[1]['records'][0]['revision']
    require(first_revision==positive_case['expected_current_revision'],'old revision expected current mismatch')
    require(older_revision==positive_case['expected_history_contains_revision'],'old revision expected history mismatch')
    require(int(older_revision)<int(first_revision),'old revision positive fixture is not older')
    drift=load(r/'fixtures/negative/snapshot-drift.json')
    require(set(drift)=={'steps'} and len(drift['steps'])==2,'snapshot drift must be a two-step sequence')
    first_step,second_step=drift['steps']; first=load(r/first_step['fixture']); second=load(r/second_step['fixture']); req1=first_step['request']; req2=second_step['request']
    require(first['has_more'] is True and second['has_more'] is True,'snapshot drift pages must both continue')
    require(req1['cursor'] is None and req2['cursor']==first['next_cursor'],'snapshot drift request order')
    require(second['next_cursor']!=first['next_cursor'],'snapshot drift second page cursor must advance')
    require(second['source_snapshot_id']!=first['source_snapshot_id'],'snapshot drift snapshot id must change')
    stable=lambda p:{k:v for k,v in p.items() if k not in {'next_cursor','source_snapshot_id'}}
    require(stable(first)==stable(second),'snapshot drift changed fields other than cursor and snapshot id')
    trans=load(r/'transport-cases.json'); require(len(trans)>=10 and all(set(x)=={'case_id','stage','setup','request_fixture','expected_status','expected_code','expected_headers','actual_result','evidence_ref'} for x in trans),'transport catalog shape')
    require(all(x['actual_result'] in {'PASS','FAIL','NOT_RUN','NOT_IMPLEMENTED'} for x in trans),'transport result enum')
    http_fields={'method','path','headers','query','body','repeat'}
    for x in trans:
        request_path=r/x['request_fixture']; require(request_path.is_file(),f"transport request fixture missing: {x['case_id']}")
        request=load(request_path); require(set(request)==http_fields,f"transport request fixture shape: {x['case_id']}")
        require(request['method'] in {'GET','POST','PUT','PATCH','DELETE','HEAD'} and request['path'].startswith('/'),f"transport request method/path: {x['case_id']}")
        require(isinstance(request['headers'],dict) and isinstance(request['query'],dict) and isinstance(request['repeat'],int) and request['repeat']>=1,f"transport request fields: {x['case_id']}")
        require(isinstance(x['evidence_ref'],str) and x['evidence_ref'],f"transport evidence missing: {x['case_id']}")
        evidence=r/x['evidence_ref']; require(evidence.is_file() and evidence.stat().st_size>0,f"transport evidence file missing or empty: {x['case_id']}")
    wrong_tenant=next((x for x in trans if x['case_id']=='T-12-WRONG-TENANT'),None)
    require(wrong_tenant is not None and wrong_tenant['expected_status']==403 and wrong_tenant['expected_code']=='FORBIDDEN' and wrong_tenant['actual_result']=='PASS','wrong-tenant transport case result')
    wrong_tenant_request=load(r/wrong_tenant['request_fixture'])
    require(wrong_tenant_request['headers'].get('Authorization')=='Bearer ${fixture:wrong-tenant-reader-token}','wrong-tenant token fixture')
    print('RETURN_PACKAGE=PASS'); print(f'FILES={len(files)+1}'); print(f'POSITIVE_RESPONSES={positive}'); print(f'POSITIVE_SEQUENCE_CASES={len(positive_cases)}'); print(f'NEGATIVE_CASES={len(neg)}'); print(f'TRANSPORT_CASES={len(trans)}'); print(f'IDENTITY_SHA256={m["identity_sha256"]}')
    return 0
if __name__=='__main__':
    try: raise SystemExit(main())
    except AssertionError as e: print('RETURN_PACKAGE=FAIL',e,file=sys.stderr); raise SystemExit(1)
